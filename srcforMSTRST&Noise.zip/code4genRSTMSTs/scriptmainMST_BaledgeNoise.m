function[] = scriptmainMST_BaledgeNoise()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function: Main control flow, does the avergaing runs over the experiments
%on different sizes of datasets with harmonic energy minimization using
%different methods and max flow-min cut respecting labelling methods
%
%Author: Shaona Ghosh
% Date: 11-01-2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%clear all;
close all;

%Seed the random number generator 
rng(555);
cd ('C:\Users\Shaona\Documents\MATLAB\');

%Parse data
%[data, labels, N, d] = parsedata('dtrain123.dat');
[data, labels, N, d] = parsedata('ziptrain.dat');

%Read distances from file - distances saved earlier as taking time
distpath = fullfile(pwd,'datasetdistances');
if ~exist(distpath, 'dir')
   mkdir(distpath);
end
datasetname = sprintf('%s-%s', 'ziptrain', 'distance.mat');
distpath = fullfile(distpath,datasetname);
distancematrixstruc = load(distpath,'-mat', 'distancematrixfull');
distancematrixfull = distancematrixstruc.distancematrixfull;


%vary parameters
% varK = [2,3,4,5,6,7];
%varK = [8,9,10,11,12];
varK = [9];%,4,5,6,8,20];
varL = [32,64,128];%[8,16,32,]
% varN = [200,400,600,800,1000];
varN = [1000];
noise = [20,40,60,80,100];
% lab1 = [1,2,3,4,6];
% lab2 = [2,3,8,7,9];
lab1 = [1];
lab2 = [2]

% varK = [2];
% varL = [8];
% varN = [200];
% lab1 = [1];
% lab2 = [18];

%folder creation
%exppath = fullfile(pwd,'baledgenoise4elim');
exppath = fullfile(pwd,'testbaledgeelimadd');
if ~exist(exppath, 'dir')
   mkdir(exppath);
end
% cd(exppath);


for class = 1:length(lab1)

for niter = 1:length(varN)
    
for kiter = 1:length(varK)

for liter = 1:length(varL)

for nseiter = 1:length(noise)
    
%labtype1 = 1;
%labtype2 = 2;
labtype1 = lab1(class);
labtype2 = lab2(class);
    
navgruns = 2;
    
%parameters
k = varK(kiter);
l = varL(liter);
n = varN(niter);
nse = noise(nseiter);

%Test code


%first column for labels plus no of features in dataset
%data = data(1:100,:);
%nfeat = 12+1;
%labels = labels(1:100);
nfeat = d+1;

M = 1;
    
%parameter settings directory
classstr = sprintf('class%dVs%d', labtype1, labtype2);
settingstr = sprintf('n%dl%dk%ds%d',n,l,k,nse);
settingpath = fullfile(exppath,classstr,settingstr);
if ~exist(settingpath, 'dir')
      mkdir(settingpath);
end
% cd(settingpath);            
for run = 1: navgruns
        
        %divide into random sets
        [num,fullset,distancemat1] = sampledataWeighted( labels, data, n, labtype1, labtype2, nfeat, distancematrixfull);   %Arguments:labels,data,n, labtype1, labtype2
           
            
        %build Graph
        [A,D,L,edgesnotin,MSTedges] = builddatasetgraphWeighted_baledgenoise(num, fullset, distancemat1, k);
        
        
        
        %Add edge noise to the graph at trial run
        [rw,cl] = find(A);
        edgesingraph = horzcat(rw,cl);
        noedges = length(rw);
%         nnoisyedges = round((nse/100)*noedges);%could be a fixed value need to verify
%         %sample 10% edges to replace randomly
%         randedges = randperm(noedges);
%         randedges = randedges(1:nnoisyedges);
%         edgesseltorem = horzcat(rw(randedges),cl(randedges));
%         edgesseltoremrev = fliplr(edgesseltorem);
% 
%         edgestoremove = vertcat(edgesseltorem,edgesseltoremrev);
%         [la,Lb] = ismember(edgestoremove,edgesingraph,'rows');
%         edgesingraph(Lb,:) = [];
%         cntedges = length(edgesingraph);
%         
%         
%     
%         
%         %Sample equal number of random egdes to add
%         randedges = randperm(length(edgesnotin));
%         randedges = randedges(1:nnoisyedges)
%         edgesseltoadd = edgesnotin(randedges,:);
%         edgesseltoaddrev = fliplr(edgesseltoadd);
% 
%         edgesingraph(cntedges+1:cntedges+length(edgesseltoadd),:) = edgesseltoadd;
%         edgesingraph(length(edgesingraph)+1:length(edgesingraph)+length(edgesseltoaddrev),:) = edgesseltoaddrev;
%         cntedges = length(edgesingraph);
%         edgelistmat = zeros(cntedges,3);
%         edgelistmat(:,:) = horzcat(edgesingraph,ones(cntedges,1));
        

        %first include all the spanning tree edges to ensure connectivity
        cntmstedges = length(MSTedges);
        edgelistmat = zeros(noedges,3);
        edgelistmat(1:cntmstedges,:) = horzcat(MSTedges, ones(cntmstedges,1));
        
        %now flip a coin for every edges, include if less than bias, if
        %greater than bias, invent new random edge
        bias  = nse/100;%1/nse;
        randop = rand(noedges,1);
        lessbias = (randop > bias);
        edgeincl = find(lessbias);
        edgelistmat(cntmstedges+1:cntmstedges+length(edgeincl),:) = horzcat(edgesingraph(edgeincl,:),ones(length(edgeincl),1));
        cntmstedges = cntmstedges + length(edgeincl);
        edgelistmat(cntmstedges+1:cntmstedges+length(edgeincl),:) = horzcat(edgesingraph(edgeincl,end:-1:1),ones(length(edgeincl),1));
        cntmstedges = cntmstedges + length(edgeincl);
        
        cntedgesrem = noedges - length(edgeincl);
        
        %invent and add new invented edges as many as removed
        if cntedgesrem > 1
            for iij  = 1:cntedgesrem
                randverti = randi(num,1);
                randvertj = randi(num,1);
                edgetoinclude = horzcat(randverti,randvertj);
                edgetoinclude = horzcat(edgetoinclude,1);
                edgelistmat(cntmstedges+1:cntmstedges+1,:) = edgetoinclude;
                edgetoinclude = horzcat(randvertj,randverti);
                edgetoinclude = horzcat(edgetoinclude,1);
                cntmstedges = cntmstedges + 1;
                edgelistmat(cntmstedges+1:cntmstedges+1,:) = edgetoinclude;
                cntmstedges = cntmstedges + 1;
            end
        end
        
        edgelistmat(cntmstedges+1:end,:) = [];
        
        

        datasetname = sprintf('datasetgraph%d%d.csv', num,run);
        path = fullfile(settingpath,datasetname);
        %graphname = sprintf('datasetgraph%d%d.csv',nofsets(c),run);
        cd(settingpath);
        dlmwrite(path,edgelistmat, '\t')
        cd ('C:\Users\Shaona\Documents\MATLAB\');  
        
        %sample two classes randomly
        [partlab1, partlab2, nodelabi, nodelabj, f_j] = samplelabels(num,fullset(:,1), l);
        
        
        [r,c,v] = find(f_j)
        f_j(f_j==-1) = 0;
        f_j(f_j==1) = 1;
        trdata = [r,v];
        trainingsetname = sprintf('trainingset%d%d.csv', num,run);
        path = fullfile(settingpath,trainingsetname);
        %trainsetname = sprintf('trainingset%d%d.csv',nofsets(c),run);
        cd(settingpath);
        csvwrite(path,trdata);
        
        labsetname = sprintf('labset%d%d%d.csv', num,run,0);
        path = fullfile(settingpath,labsetname);
        %labsetname = sprintf(path,'%d%d%d.csv', nofsets(c),run,0);
        labs = fullset(:,1);
        labs(labs==-1) = 0;
        labs(labs==1) = 1;
        labmat = [(1:1:num)',labs];
        csvwrite(path,labmat);
        cd ('C:\Users\Shaona\Documents\MATLAB\');  
        
        
        run
       
        
        
        
end

end
            
          
end

end

end %loop for class

end %noise level
    
end