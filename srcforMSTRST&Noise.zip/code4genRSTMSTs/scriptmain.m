function[] = scriptmain()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function: Main control flow, does the avergaing runs over the experiments
%on different sizes of datasets with harmonic energy minimization using
%different methods and max flow-min cut respecting labelling methods
%
%Author: Shaona Ghosh
% Date: 11-01-2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%clear all;
close all;

%Seed the random number generator 
rng(555);
cd ('C:\Users\Shaona\Documents\MATLAB\');
%parse the file 
%[data, labels, N, d] = parsedata('dtrain123.dat');


[data, labels, N, d] = parsedata('ziptrain.dat');
%[data, labels, N, d] = processisolet();%Isolet does not have more than 300 per letter
data(1:10,1:10)
labels(1:10)
%vary parameters
% varK = [20, 40, 60, 80];                      %superbal isolet - 
% 1400
% varK = [4]                              %digits 1 vs 2--ADDING 1400 nodes for 6 and 7
% % varK = [8,9,10,11];                           %isolet
% %varK  = [7,6,5,4,3];                           %digits 1 vs 2 small K has to be superbal for varN = [600,800,1000,1200,1400];
% 
% %varL = [20,40,60,80,100];  
% % varL = [26,52,78,104,130];                        %superbal isolet
% % varL = [20,40,60,80];                             %digits 1 vs 2
% % varL = [10,20,30,40,50];                          %digits superbalanced
% % varL = [16,32,64,128,256];                        %digits superbalanced
% 
% varL = [40,80,160];
% 
% 
% varN = [600];
%varN = [1000,1200];                     %digits 1 vs 2
%varN = [1400,1200,1000,800,600];                  %isolet supbal
%varN = [600,800,1000];


varK = [4,7]; 
varL = [4,8,16,32]; 
varN = [150,300,600,1200];


%folder creation
exppath = fullfile(pwd,'6vs7150N');
if ~exist(exppath, 'dir')
   mkdir(exppath);
end
% cd(exppath);
for niter = 1:length(varN)
    
for kiter = 1:length(varK)

for liter = 1:length(varL)
    
labtype1 = 6;
labtype2 = 7;
    
navgruns = 10;
    
%parameters
k = varK(kiter);
l = varL(liter);
n = varN(niter);
M = 1;
    
f_hat_mat = zeros(n,M);

%parameter settings directory
settingstr = sprintf('n%dl%dk%d',n,l,k);
settingpath = fullfile(exppath,settingstr);
if ~exist(settingpath, 'dir')
      mkdir(settingpath);
end
% cd(settingpath);            
for run = 1: navgruns
        %first column for labels plus no of features in dataset
        nfeat = d+1;
        %divide into random sets
        [num,fullset] = sampledata( labels, data, n, labtype1, labtype2, nfeat);   %Arguments:labels,data,n, labtype1, labtype2
        
        %distance computation
        [distancemat1] = distances( fullset, num, nfeat);  %Third parameter default to 258
        
        %build Graph
        [A,D,L] = builddatasetgraph(num, fullset, distancemat1, k);
        %check if graph connected
        isconn = isconnected(A);
        while(~isconn)%keep building new graph until connected
             [A,D,L] = builddatasetgraph(num, fullset, distancemat1, k);
             isconn = isconnected(A);
        end
             
        %Write to file
        [rw,cl] = find(A);
        wts = ones(length(rw),1);
        %wts = zeros(length(rw),1);
        edgelistmat = [rw,cl,wts];
        % fileID = fopen('simgraph.csv','w');
        % fprintf(fileID,'%d\t%d\t0\n',edgelistmat);
        % fclose(fileID);
        datasetname = sprintf('datasetgraph%d%d.csv', num,run);
        path = fullfile(settingpath,datasetname);
        %graphname = sprintf('datasetgraph%d%d.csv',nofsets(c),run);
        cd(settingpath);
        dlmwrite(path,edgelistmat, '\t')
        cd ('C:\Users\Shaona\Documents\MATLAB\');  
        
        %sample two classes randomly
        [partlab1, partlab2, nodelabi, nodelabj, f_j] = samplelabels(num,fullset(:,1), l);
        
        
        [r,c,v] = find(f_j)
        f_j(f_j==-1) = 0;
        f_j(f_j==1) = 1;
        trdata = [r,v];
        trainingsetname = sprintf('trainingset%d%d.csv', num,run);
        path = fullfile(settingpath,trainingsetname);
        %trainsetname = sprintf('trainingset%d%d.csv',nofsets(c),run);
        cd(settingpath);
        csvwrite(path,trdata);
        
        labsetname = sprintf('labset%d%d%d.csv', num,run,0);
        path = fullfile(settingpath,labsetname);
        %labsetname = sprintf(path,'%d%d%d.csv', nofsets(c),run,0);
        labs = fullset(:,1);
        labs(labs==-1) = 0;
        labs(labs==1) = 1;
        labmat = [(1:1:num)',labs];
        csvwrite(path,labmat);
        cd ('C:\Users\Shaona\Documents\MATLAB\');  
        %seminorm interpolation
        %[f_hat_mat(1:num,1)]  = optimizer('harmonicinv', partlab1, partlab2, nodelabi, nodelabj, A, D, L, num, f_j);
        
%         [f_hat_mat(1:num,2)]  = optimizer('harmonicquad', partlab1, partlab2, nodelabi, nodelabj, A, D, L, num, f_j);
%         
%         [f_hat_mat(1:num,3)]  = optimizer('maxflowlinear', partlab1, partlab2, nodelabi, nodelabj, A, D, L, num, f_j);
%         
%         [f_hat_mat(1:num,4)]  = optimizer('harplusmaxflowcons', partlab1, partlab2, nodelabi, nodelabj, A, D, L, num, f_j);
%         
%         %[f_hat_mat(1:num,1)]  = optimizer('harplusmaxflowobj', partlab1, partlab2, nodelabi, nodelabj, A, D, L, num, f_j, lambda);
%         [f_hat_mat(1:num,5)]  = optimizer('harplusmaxflowobj', partlab1, partlab2, nodelabi, nodelabj, A, D, L, num, f_j, (num)^2);
        
        %Save results
        %saveresults(run, num, k, f_hat_mat, fullset(:,1) );
        %scriptsaveres(run, num, l, k, f_hat_mat, fullset(:,1), settingpath );
        %saveresults(run, num, lambda, f_hat_mat, fullset(:,1) );
        
        run
end
    f_j'
    f_hat_mat
    %Increment counter
%     cnt = cnt+1;
end
            
          
end

end

end
    
