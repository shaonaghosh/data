function[] = scriptmainRST()
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function: Main control flow, does the avergaing runs over the experiments
%on different sizes of datasets with harmonic energy minimization using
%different methods and max flow-min cut respecting labelling methods
%
%Author: Shaona Ghosh
% Date: 11-01-2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%clear all;
close all;

%Seed the random number generator 
rng(555);
cd ('C:\Users\Shaona\Documents\MATLAB\');

%Parse data
%[data, labels, N, d] = parsedata('dtrain123.dat');
[data, labels, N, d] = parsedata('ziptrain.dat');

%Read distances from file - distances saved earlier as taking time
distpath = fullfile(pwd,'datasetdistances');
if ~exist(distpath, 'dir')
   mkdir(distpath);
end
datasetname = sprintf('%s-%s', 'ziptrain', 'distance.mat');
distpath = fullfile(distpath,datasetname);
distancematrixstruc = load(distpath,'-mat', 'distancematrixfull');
distancematrixfull = distancematrixstruc.distancematrixfull;

varK = [9];
%varL = [32,64,128];
varL = [2,4,32,64,128];
varN = [1000];
% lab1 = [1,2,3,4,6];
% lab2 = [2,3,8,7,9];
lab1 = [1];
lab2 = [2];

%varRST = [1,2,4,8];
varRST = [20];
% varK = [2];
% varL = [8];
% varN = [200];
% lab1 = [1];
% lab2 = [18];

%folder creation
exppath = fullfile(pwd,'rstsize20morel');
if ~exist(exppath, 'dir')
   mkdir(exppath);
end
% cd(exppath);

for class = 1:length(lab1)

for niter = 1:length(varN)
    
for kiter = 1:length(varK)

for liter = 1:length(varL)
    
for rstiter = 1:length(varRST)
    
%labtype1 = 1;
%labtype2 = 2;
labtype1 = lab1(class);
labtype2 = lab2(class);
    
navgruns = 10;
    
%parameters
k = varK(kiter);
l = varL(liter);
n = varN(niter);
rst = varRST(rstiter);

nfeat = d+1;

M = 1;
    
%parameter settings directory
classstr = sprintf('class%dVs%d', labtype1, labtype2);
settingstr = sprintf('n%dl%dk%drst%d',n,l,k,rst);
settingpath = fullfile(exppath,classstr,settingstr);
if ~exist(settingpath, 'dir')
      mkdir(settingpath);
end

for run = 1: navgruns
        %divide into random sets
        [num,fullset,distancemat1] = sampledataWeighted( labels, data, n, labtype1, labtype2, nfeat, distancematrixfull);   %Arguments:labels,data,n, labtype1, labtype2
           
            
        %build Graph
        [A,D,L] = builddatasetgraphWeighted(num, fullset, distancemat1, k); 
        
        Adj = A;
        finalAdj = zeros(num,num);
        for brst = 1:rst
           [tree, parent] = findRST(Adj,num);
           finalAdj = bsxfun(@or,finalAdj,tree);
        end
%         idx = find(finalAdj);
%         finalAdj(idx) = 1;
        

        A = finalAdj;
        %Write to file
        [rw,cl] = find(A);
        %bconn = isconnected(A);
        wts = ones(length(rw),1);
        %wts = zeros(length(rw),1);
        edgelistmat = [rw,cl,wts];
        % fileID = fopen('simgraph.csv','w');
        % fprintf(fileID,'%d\t%d\t0\n',edgelistmat);
        % fclose(fileID);
        datasetname = sprintf('datasetgraph%d%d.csv', num,run);
        path = fullfile(settingpath,datasetname);
        %graphname = sprintf('datasetgraph%d%d.csv',nofsets(c),run);
        cd(settingpath);
        dlmwrite(path,edgelistmat, '\t')
        cd ('C:\Users\Shaona\Documents\MATLAB\');  
        
        %sample two classes randomly
        [partlab1, partlab2, nodelabi, nodelabj, f_j] = samplelabels(num,fullset(:,1), l);
        
        
        [r,c,v] = find(f_j)
        f_j(f_j==-1) = 0;
        f_j(f_j==1) = 1;
        trdata = [r,v];
        trainingsetname = sprintf('trainingset%d%d.csv', num,run);
        path = fullfile(settingpath,trainingsetname);
        %trainsetname = sprintf('trainingset%d%d.csv',nofsets(c),run);
        cd(settingpath);
        csvwrite(path,trdata);
        
        labsetname = sprintf('labset%d%d%d.csv', num,run,0);
        path = fullfile(settingpath,labsetname);
        %labsetname = sprintf(path,'%d%d%d.csv', nofsets(c),run,0);
        labs = fullset(:,1);
        labs(labs==-1) = 0;
        labs(labs==1) = 1;
        labmat = [(1:1:num)',labs];
        csvwrite(path,labmat);
        cd ('C:\Users\Shaona\Documents\MATLAB\');  
        
    
end


end

end

end

end

end

end